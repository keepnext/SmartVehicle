#ifndef LIDAR_SAMPLE_H
#define LIDAR_SAMPLE_H
#include <QWidget>

class lidar_sample : public QWidget
{
public:
       lidar_sample(QWidget* parent =nullptr);
       ~lidar_sample();
};

#endif // LIDAR_SAMPLE_H
