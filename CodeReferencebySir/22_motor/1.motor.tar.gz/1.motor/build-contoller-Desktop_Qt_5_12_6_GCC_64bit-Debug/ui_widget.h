/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QPushButton *conn;
    QTextEdit *textEdit;
    QLabel *label;
    QPushButton *accel;
    QPushButton *brake;
    QLabel *label_2;
    QLCDNumber *lcd;
    QLineEdit *motorip;
    QLineEdit *motorport;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(531, 426);
        conn = new QPushButton(Widget);
        conn->setObjectName(QString::fromUtf8("conn"));
        conn->setGeometry(QRect(10, 5, 131, 31));
        textEdit = new QTextEdit(Widget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(230, 110, 291, 311));
        label = new QLabel(Widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(230, 80, 291, 17));
        accel = new QPushButton(Widget);
        accel->setObjectName(QString::fromUtf8("accel"));
        accel->setGeometry(QRect(10, 170, 121, 91));
        accel->setAutoRepeat(true);
        accel->setAutoRepeatInterval(1000);
        brake = new QPushButton(Widget);
        brake->setObjectName(QString::fromUtf8("brake"));
        brake->setGeometry(QRect(10, 290, 121, 91));
        brake->setAutoRepeat(true);
        brake->setAutoRepeatInterval(1000);
        label_2 = new QLabel(Widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 80, 111, 17));
        lcd = new QLCDNumber(Widget);
        lcd->setObjectName(QString::fromUtf8("lcd"));
        lcd->setGeometry(QRect(100, 80, 111, 23));
        lcd->setFrameShadow(QFrame::Plain);
        lcd->setSmallDecimalPoint(false);
        lcd->setSegmentStyle(QLCDNumber::Flat);
        motorip = new QLineEdit(Widget);
        motorip->setObjectName(QString::fromUtf8("motorip"));
        motorip->setGeometry(QRect(148, 10, 113, 25));
        motorport = new QLineEdit(Widget);
        motorport->setObjectName(QString::fromUtf8("motorport"));
        motorport->setGeometry(QRect(270, 10, 61, 25));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        conn->setText(QApplication::translate("Widget", "\353\252\250\355\204\260 \354\240\234\354\226\264\352\270\260 \354\227\260\352\262\260", nullptr));
        label->setText(QApplication::translate("Widget", "\355\230\204\354\236\254 \353\252\250\355\204\260 \354\203\201\355\203\234", nullptr));
        accel->setText(QApplication::translate("Widget", "\352\260\200\354\206\215", nullptr));
        brake->setText(QApplication::translate("Widget", "\352\260\220\354\206\215", nullptr));
        label_2->setText(QApplication::translate("Widget", "\353\252\251\355\221\234 RPM : ", nullptr));
        motorip->setText(QApplication::translate("Widget", "192.168.0.22", nullptr));
        motorport->setText(QApplication::translate("Widget", "9001", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
