{
    "response": {
    "status": "200",
    "message": "Correct request"
},
"data": [
    [
        {
            "href": "link",
            "text": "string matr"
        },
        {
            "href": "link",
            "text": "string type"
        },
        {
            "href": "link",
            "text": "string name"
        },
        {
            "href": "link",
            "text": "string state"
        }
    ]

]
}
