#include "widget.h"
#include "ui_widget.h"

#include <QTcpSocket>
#include <QHostAddress>
#include <QDebug>

#include <QTime>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    initialize();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::timerEvent(QTimerEvent *event)
{
    if(tcpSocket->state() == QAbstractSocket::ConnectedState)
    {
        QString strSend = QString::number(iTargetRPM);
        qDebug() << Q_FUNC_INFO << iTargetRPM;
        tcpSocket->write(strSend.toUtf8());
    }
}

void Widget::initialize()
{
    tcpSocket = new QTcpSocket(this);

    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(readMessage()));
    connect(tcpSocket, SIGNAL(disconnected()), this, SLOT(disconnected()));
    connect(tcpSocket, SIGNAL(connected()), this, SLOT(connected()));
    connect(ui->conn, SIGNAL(clicked()), this, SLOT(connectButton()));
    connect(ui->accel, SIGNAL(clicked()), this, SLOT(accel()));
    connect(ui->brake, SIGNAL(clicked()), this, SLOT(brake()));

    iTargetRPM = 0;
}

void Widget::connectButton()
{
    QString motorip   = ui->motorip->text().trimmed();
    QString motorport   = ui->motorport->text().trimmed();

    QHostAddress serverAddress(motorip);
    tcpSocket->connectToHost(serverAddress, motorport.toUShort());

    qDebug() << Q_FUNC_INFO << "서버 접속 요청";
}

void Widget::connected()
{
    qDebug() << Q_FUNC_INFO << "서버 접속 완료";
    startTimer(1000);
}

void Widget::readMessage()
{
    if(tcpSocket->bytesAvailable() >= 0)
    {
        // 상태값 수신
        QByteArray readData = tcpSocket->readAll();
        QString strRecv(readData);
        qDebug() << strRecv;
        ui->textEdit->setText("현재시간 : " + QTime::currentTime().toString());
        ui->textEdit->append(strRecv);
    }
}

void Widget::disconnected()
{
    tcpSocket->close();
    qDebug() << Q_FUNC_INFO << "서버 접속 종료.";
}

void Widget::accel()
{
    if(iTargetRPM < 1000)
    {
        iTargetRPM += 100;
    }
    ui->lcd->display(iTargetRPM);
}

void Widget::brake()
{
    if(iTargetRPM >= 100)
    {
        iTargetRPM -= 100;
    }
    else
    {
        iTargetRPM = 0;
    }
    ui->lcd->display(iTargetRPM);
}

