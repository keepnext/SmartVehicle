#include "ultra.h"
#include "imu.h"
#include "lidar.h"
#include "lidar_adv.h"
#include "camera.h"
#include "camera_adv.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    ultra w;
    w.move(0,0);
    //w.setWindowFlags(Qt::FramelessWindowHint);
    w.show();
    imu w2;
    w2.move(530,0);
    //w2.setWindowFlags(Qt::FramelessWindowHint);
    w2.show();
    lidar w3;
    w3.move(930,0);
    //w3.setWindowFlags(Qt::FramelessWindowHint);
    w3.show();
    lidar_adv w4;
    w4.move(0,500);
    //w4.setWindowFlags(Qt::FramelessWindowHint);
    w4.show();
    camera w5;
    w5.move(530,500);
    //w5.setWindowFlags(Qt::FramelessWindowHint);
    w5.show();
    camera_adv w6(nullptr, &w4);
    w6.move(930,500);
    //w5.setWindowFlags(Qt::FramelessWindowHint);
    w6.show();

    ///imu + lidar 연동 추가
    QObject::connect(&w2, SIGNAL(imusend(int)), &w4, SLOT(imuRecv(int)));
    return a.exec();
}
