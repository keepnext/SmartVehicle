#ifndef CAMERA_H
#define CAMERA_H

#include <QWidget>
#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

QT_BEGIN_NAMESPACE
namespace Ui { class Camera; }
class QTcpSocket;
QT_END_NAMESPACE

class camera : public QWidget
{
    Q_OBJECT

public:
    camera(QWidget *parent = nullptr);
    ~camera();

protected:
    void paintEvent(QPaintEvent *event);

private:
    Ui::Camera *ui;
    QTcpSocket *tcpSocket;

    cv::Mat img;
    QByteArray imgByte;

    void initialize();

private slots:
    void timerEvent(QTimerEvent* event);
    void connectButton();
    void connected();
    void readMessage();
    void disconnected();
};
#endif // CAMERA_H
