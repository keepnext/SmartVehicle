#ifndef LIDAR_ADV_H
#define LIDAR_ADV_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class Lidar_Adv; }
class QTcpSocket;
QT_END_NAMESPACE

class lidar_adv : public QWidget
{
    Q_OBJECT

public:
    lidar_adv(QWidget *parent = nullptr);
    ~lidar_adv();

protected:
    void paintEvent(QPaintEvent *event);

private:
    Ui::Lidar_Adv *ui;
    QTcpSocket *tcpSocket;

    QString strRecved;
    int iUltraDist_in;
    int iUltraDist_cm;
    QString strMsg;
    void initialize();

    int iDist[360];

    // imu + lidar 연동 추가
    int iImuRecv;

    // camera_adv에서 접근할 수 있도록 public 변경
    public:
        int iDist_Buf[360];

private slots:
    void timerEvent(QTimerEvent* event);
    void connectButton();
    void connected();
    void readMessage();
    void disconnected();

public slots:
    ///imu + lidar 연동 추가
    void imuRecv(int);
};

#endif // LIDAR_ADV_H
