#include "camera.h"
#include "ui_camera.h"

#include <QTcpSocket>
#include <QHostAddress>
#include <QDebug>
#include <QPainter>

#include <QTime>

camera::camera(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Camera)
{
    ui->setupUi(this);
    initialize();
}

camera::~camera()
{
    delete ui;
}

void camera::initialize()
{
    tcpSocket = new QTcpSocket(this);

    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(readMessage()));
    connect(tcpSocket, SIGNAL(disconnected()), this, SLOT(disconnected()));
    connect(tcpSocket, SIGNAL(connected()), this, SLOT(connected()));
    connect(ui->conn, SIGNAL(clicked()), this, SLOT(connectButton()));
}

void camera::connectButton()
{
    QString sensorip   = ui->sensorip->text().trimmed();
    QString sensorport   = ui->sensorport->text().trimmed();

    QHostAddress serverAddress(sensorip);
    tcpSocket->connectToHost(serverAddress, sensorport.toUShort());

    qDebug() << Q_FUNC_INFO << "서버 접속 요청";
}

void camera::connected()
{
    qDebug() << Q_FUNC_INFO << "서버 접속 완료";
}

void camera::readMessage()
{
    if(tcpSocket->bytesAvailable() >= 0)
    {
        // 영상값 수신
        QByteArray readData = tcpSocket->readAll();
        imgByte.append(readData);
        ui->value->setText("현재시간 : " + QTime::currentTime().toString() + "," + QString::number(readData.count()));
        if(imgByte.count() >= 480 * 640 * 3)
        {
            cv::Mat tmp(480, 640, CV_8UC3, imgByte.data());
            img = tmp.clone();
            imgByte.remove(0, 480*640*3);

            QImage image( img.data,
                          img.cols, img.rows,
                          static_cast<int>(img.step),
                          QImage::Format_RGB888 );
            ui->sensor->setPixmap(QPixmap::fromImage(image));
        }
    }
}

void camera::disconnected()
{
    tcpSocket->close();
    qDebug() << Q_FUNC_INFO << "서버 접속 종료.";
}

void camera::paintEvent(QPaintEvent *event)
{
}

void camera::timerEvent(QTimerEvent* event)
{
}
