#include "lidar_adv.h"
#include "ui_lidar_adv.h"

#include <QTcpSocket>
#include <QHostAddress>
#include <QDebug>
#include <QPainter>

#include <QTime>

lidar_adv::lidar_adv(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Lidar_Adv)
{
    ui->setupUi(this);
    initialize();
}

lidar_adv::~lidar_adv()
{
    delete ui;
}

void lidar_adv::initialize()
{
    tcpSocket = new QTcpSocket(this);

    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(readMessage()));
    connect(tcpSocket, SIGNAL(disconnected()), this, SLOT(disconnected()));
    connect(tcpSocket, SIGNAL(connected()), this, SLOT(connected()));
    connect(ui->conn, SIGNAL(clicked()), this, SLOT(connectButton()));

    for(int i=0; i<360; i++)
    {
        iDist[i] = 0;
        iDist_Buf[i] = 0;
    }


    ///imu + lidar 연동 추가
    iImuRecv = 0;
}

void lidar_adv::connectButton()
{
    QString sensorip   = ui->sensorip->text().trimmed();
    QString sensorport   = ui->sensorport->text().trimmed();

    QHostAddress serverAddress(sensorip);
    tcpSocket->connectToHost(serverAddress, sensorport.toUShort());

    qDebug() << Q_FUNC_INFO << "서버 접속 요청";
}

void lidar_adv::connected()
{
    qDebug() << Q_FUNC_INFO << "서버 접속 완료";
    startTimer(1000);
}

void lidar_adv::readMessage()
{
    if(tcpSocket->bytesAvailable() >= 0)
    {
        // 상태값 수신
        QByteArray readData = tcpSocket->readAll();
        QString strRecv(readData);
        qDebug() << strRecv;

        int iStartPos = strRecv.indexOf("[", 0, Qt::CaseInsensitive);
        int iEndPos = strRecv.indexOf("]", 0, Qt::CaseInsensitive);
        if(iStartPos > -1)
        {
            if(iEndPos <= iStartPos)
            {
                // 오류 데이터 버림
            }
            else
            {
                QString strMid = strRecv.mid(iStartPos+1, iEndPos - iStartPos - 1);
                qDebug() << strMid;
                strMid.remove(0,1);
                QStringList listRad = strRecv.split("|");

                for(int i = 0; i < listRad.count(); i++)
                {
                    QString strRad = listRad[i].mid(4, listRad[i].length());
                    iDist[i] = strRad.toInt();
                    iDist_Buf[i] = strRad.toInt();
                }
            }
        }
    }
}

void lidar_adv::disconnected()
{
    tcpSocket->close();
    qDebug() << Q_FUNC_INFO << "서버 접속 종료.";
}

void lidar_adv::paintEvent(QPaintEvent *event)
{
    QPainter *painter = new QPainter(this);

    painter->translate(width()/2, ui->sensor->y() + ui->sensor->height() / 2);

    ///imu + lidar 연동 추가
    painter->rotate(iImuRecv);

    painter->setPen(QPen(Qt::green, 2));
    painter->drawLine(0, 0, 0, -50);
    painter->setPen(QPen(Qt::blue, 1));
    painter->drawArc(40 / -2, 40 / -2, 40, 40, 0, 360 * 16);
    painter->drawText(20, 20, "20cm");
    painter->drawArc(100 / -2, 100 / -2, 100, 100, 0, 360 * 16);
    painter->drawText(40, 40, "50cm");
    painter->drawArc(200 / -2, 200 / -2, 200, 200, 0, 360 * 16);
    painter->drawText(80, 80, "100cm");

    painter->rotate(ui->rad->text().toInt());


    painter->setPen(QPen(Qt::blue, 5));
    painter->drawPoint(0, 0);

    painter->setPen(QPen(Qt::red, 5));
    for(int i=0; i<360; i++)
    {
        if(iDist[i] != 0)
        {
            painter->drawPoint(iDist[i] / 10, 0); // 1cm단위 1px당 약 1mm
            iDist[i] = 0;
        }
        painter->rotate(-1);
    }

    delete painter;
}

void lidar_adv::timerEvent(QTimerEvent* event)
{
    update();
}

void lidar_adv::imuRecv(int iImuRad)
{
    ///imu + lidar 연동 추가
    iImuRecv = iImuRad;
}
