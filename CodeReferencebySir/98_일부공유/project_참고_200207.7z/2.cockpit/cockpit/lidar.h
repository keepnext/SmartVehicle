#ifndef LIDAR_H
#define LIDAR_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class Lidar; }
class QTcpSocket;
QT_END_NAMESPACE

class lidar : public QWidget
{
    Q_OBJECT

public:
    lidar(QWidget *parent = nullptr);
    ~lidar();

protected:
    void paintEvent(QPaintEvent *event);

private:
    Ui::Lidar *ui;
    QTcpSocket *tcpSocket;

    QString strRecved;
    int iUltraDist_in;
    int iUltraDist_cm;
    QString strMsg;
    void initialize();

    int iDist[360];

private slots:
    void timerEvent(QTimerEvent* event);
    void connectButton();
    void connected();
    void readMessage();
    void disconnected();
};

#endif // LIDAR_H
