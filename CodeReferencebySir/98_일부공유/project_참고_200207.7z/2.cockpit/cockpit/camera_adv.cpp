#include "camera_adv.h"
#include "lidar_adv.h"
#include "ui_camera.h"

#include <QTcpSocket>
#include <QHostAddress>
#include <QDebug>
#include <QPainter>

#include <QTime>

camera_adv::camera_adv(QWidget *parent, lidar_adv *objLidar)
    : QWidget(parent)
    , ui(new Ui::Camera)
{
    ui->setupUi(this);
    initialize();

    setWindowTitle("CAM_Adv");
    obj = objLidar;
}

camera_adv::~camera_adv()
{
    delete ui;
}

void camera_adv::initialize()
{
    tcpSocket = new QTcpSocket(this);

    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(readMessage()));
    connect(tcpSocket, SIGNAL(disconnected()), this, SLOT(disconnected()));
    connect(tcpSocket, SIGNAL(connected()), this, SLOT(connected()));
    connect(ui->conn, SIGNAL(clicked()), this, SLOT(connectButton()));
}

void camera_adv::connectButton()
{
    QString sensorip   = ui->sensorip->text().trimmed();
    QString sensorport   = ui->sensorport->text().trimmed();

    QHostAddress serverAddress(sensorip);
    tcpSocket->connectToHost(serverAddress, sensorport.toUShort());

    qDebug() << Q_FUNC_INFO << "서버 접속 요청";
}

void camera_adv::connected()
{
    qDebug() << Q_FUNC_INFO << "서버 접속 완료";
}

void camera_adv::readMessage()
{
    if(tcpSocket->bytesAvailable() >= 0)
    {
        // 영상값 수신
        QByteArray readData = tcpSocket->readAll();
        imgByte.append(readData);
        ui->value->setText("현재시간 : " + QTime::currentTime().toString() + "," + QString::number(readData.count()));
        if(imgByte.count() >= 480 * 640 * 3)
        {
            cv::Mat tmp(480, 640, CV_8UC3, imgByte.data());
            img = tmp.clone();

            // #1. opencv로 그리는 방법

            for(int i = 0 ; i<160; i++)
            {
                int iRadDist = i+180;
                cv::Scalar color;
                if(obj->iDist_Buf[iRadDist] > 500)
                {
                    color = cv::Scalar(0, 0, 255);
                }
                else if(obj->iDist_Buf[iRadDist] > 200)
                {
                    color = cv::Scalar(255, 255, 0);
                }
                else if(obj->iDist_Buf[iRadDist] > 10)
                {
                    color = cv::Scalar(255, 0, 0);
                }

                cv::line(img, cv::Point(640-i*4, tmp.size().height / 2), cv::Point(640-i*4, tmp.size().height / 2), color, 2);
            }
            // -------

            imgByte.remove(0, 480*640*3);

            QImage image( img.data,
                          img.cols, img.rows,
                          static_cast<int>(img.step),
                          QImage::Format_RGB888 );


            QPixmap pixmap = QPixmap::fromImage(image);
            // #2. pixmap으로 그리는 방법
//            QPainter paint(&pixmap);
//            paint.setPen(QPen(Qt::white, 4));
//            for(int i = 0 ; i<160; i++)
//            {
//                int iRadDist = i+180;
//                if(obj->iDist_Buf[iRadDist] > 500)
//                {
//                    paint.setPen(QPen(Qt::green, 4));
//                }
//                else if(obj->iDist_Buf[iRadDist] > 200)
//                {
//                    paint.setPen(QPen(Qt::yellow, 4));
//                }
//                else if(obj->iDist_Buf[iRadDist] > 10)
//                {
//                    paint.setPen(QPen(Qt::red, 4));
//                }

//                paint.drawPoint(640-i*4, pixmap.height() / 2);
//
//            }
            // -------

            ui->sensor->setPixmap(pixmap);
        }
    }
}

void camera_adv::disconnected()
{
    tcpSocket->close();
    qDebug() << Q_FUNC_INFO << "서버 접속 종료.";
}

void camera_adv::paintEvent(QPaintEvent *event)
{
}

void camera_adv::timerEvent(QTimerEvent* event)
{
}
